require("tm")||install.packages("tm")
require("rJava")||install.packages("rJava")
require("wordcloud")||install.packages("wordcloud")
require("textir")||install.packages("textir")
require("RWeka")||install.packages("RWeka")
require("qdap")||install.packages("qdap")
require("maptpx")||install.packages("maptpx")

library("tm")
library("rJava")
library("wordcloud")
library("textir")
library("RWeka")
library("qdap")
library("maptpx")

############################################################
#           Read the Text Data in R                        # 
############################################################
text  = readLines (file.choose())     # Select txt file you want to analyse
head(text)

Doc.id=seq(1:length(text))            # Assign Document no for each Document 
calib=data.frame(Doc.id,text)         # Create a dataframe for text documents with document ID

stpw = readLines(file.choose())      # Select stopwords.txt file
stpw1 = stopwords('english')         # tm package stop word list
comn  = unique(c(stpw, stpw1))       # Union of two list
stopwords = unique(c(gsub("'","",comn),comn)) # final stop word lsit after removing punctuation
head (stopwords)


#############################################################
#                        Text Cleaning                      #
#############################################################

test = text.clean(text)                         # basic HTML Cleaning etc
test  =  removeWords(test,stopwords)            # removing stopwords created above
head(test)                                      # print top documents

clean_text = test

write(clean_text, file="cleaned_data_amazon_review_iphone_5s.txt")
write(clean_text, file="cleaned_data_twitter_tweets_iphone_5s.txt")
write(clean_text, file="cleaned_data_google_news_iphone_5s.txt")

########################################################
#             Create Document Term Matrix              #
########################################################

x1 = Corpus(VectorSource(test))          # Create the corpus
x1 = n.gram(x1,"bi",3)                   # Encoding bi-gram with atleast frequency 3 as uni-gram

dtm1 = custom.dtm(x1,"tf")               # Document Term Frequency 
dtm2 = custom.dtm(x1,"tfidf")            # Term Frequency Inverse Document Frequency Scheme


######################################################
#         Basic Analysis                             #

#   1- Using Term frequency(tf)             

freq1 = (sort(apply(dtm1,2,sum), decreasing =T)) # Calcualte term frequency
freq1[1:80]                                     # View top 80 terms 

windows()  # New plot window
wordcloud(names(freq1), freq1, scale=c(4,0.5),1, max.words=200,colors=brewer.pal(8, "Dark2")) # Plot results in a word cloud 
title(sub = "Term Frequency - Wordcloud")


#   2- UsingTerm Frequency Inverse Document Frequency (tfidf)             
freq2 = (sort(apply(-dtm2,2,sum), decreasing =T)) # Calcualte term frequency
freq2=-freq2
freq2[1:80]   

# View top 80 terms 

windows()  # New plot window
wordcloud(names(freq2), freq2, scale=c(4,0.5),1, max.words=200,colors=brewer.pal(8, "Dark2")) # Plot results in a word cloud 
title(sub = "Term Frequency Inverse Document Frequency - Wordcloud")



###########################################################
#         Sentiment Analysis                              #
###########################################################

dtm = as.matrix(dtm1)

pos.words.wt=read.csv(file.choose(),header=T,sep="\t")  # read-in positive_words.txt  # Source http://www.cs.uic.edu/~liub/FBS/sentiment-analysis.html #(LEN(A2)-MIN(LEN(A2),3.9))*0.1
head(pos.words.wt)

neg.words.wt=read.csv(file.choose(),header=T,sep="\t")   # read-in negative_words.txt  # Source http://www.cs.uic.edu/~liub/FBS/sentiment-analysis.html
head(neg.words.wt)

pos.words=unique(c(as.character(pos.words.wt$word),"wow", "kudos", "hurray")) 			# including our own positive words to the existing list

neg.words = unique(c(as.character(neg.words.wt$word)))

pos.matches = match(colnames(dtm), pos.words) 		# match() returns the position of the matched term or NA

pos.matches = !is.na(pos.matches)                 # Convert to logical variable
b1 = colSums(dtm)[pos.matches]
b1 = as.data.frame(b1)

colnames(b1) = c("freq")

windows();
wordcloud(rownames(b1), b1[,1], scale=c(5, 1), colors=1:10)  	# wordcloud of positive words

neg.matches = match(colnames(dtm), neg.words)


neg.matches = !is.na(neg.matches)

b2 = colSums(dtm)[neg.matches]
b2 = as.data.frame(b2)
colnames(b2) = c("freq")
windows();
wordcloud(rownames(b2), b2[,1], scale=c(5, 1), colors=1:10)  	 # wordcloud of negative words


#################################################
## --- model based text analytics ------ ###
#################################################

K = 6
## Bayes Factor model selection (should choose K or nearby)

summary(simselect <- topics(dtm1, K=K+c(-4:4)), nwrd=0)
K = 2;   # Change simselect$K to any the number of topics you want to fit in model

# -- run topic model for selected K -- #
summary( simfit <- topics(dtm1,  K=K, verb=2), nwrd = 12 )
rownames1 = gsub(" ", ".", rownames(simfit$theta));  rownames(simfit$theta) = rownames1;  

#######################################################
### compute lift for all terms across all topics ###

theta = simfit$theta

lift = theta*0;  sum1 = sum(dtm1)

for (i in 1:nrow(theta)){  
  for (j in 1:ncol(theta)){
    
    ptermtopic = 0; pterm = 0;
    
    ptermtopic = theta[i, j]
    
    pterm = sum(dtm1[,i])/sum1
    
    lift[i, j] = ptermtopic/pterm
    
  }}


######################################
# Plot Wordcloud for each topic
for   (my_i in 1:ncol(lift)) {
  freq = as.matrix((theta)[(match(rownames((lift)[((lift)[,my_i] > 1),]),rownames((theta)))),][,my_i])
  freq = as.matrix(freq[(order(freq[,1], decreasing=T)),])
  {if (nrow(freq) >= 100) {n = 100}
  else {n = nrow(freq)}
  }
  top_word = as.matrix(freq[1:n,])
  #plot.new()
  windows()
  wordcloud(rownames(top_word), top_word,  scale=c(4,0.5), 1, , random.order=FALSE, random.color=FALSE, colors=brewer.pal(8, "Dark2"));
  mtext(paste("Latent Topic",my_i), side = 3, line = 2, cex=2)
}

##########################################
# Calculate Document proportion in topics

eta = function(mat, dtm) {
  mat1 = mat/mean(mat);  terms1 = rownames(mat1);
  eta.mat = matrix(0, 1, ncol(mat1))
  
  for (i in 1:nrow(dtm)){
    a11 = as.data.frame(matrix(dtm[i,]));  rownames(a11) = colnames(dtm)
    a12 = as.matrix(a11[(a11>0),]);  rownames(a12) = rownames(a11)[(a11>0)];  rownames(a12)[1:4]
    a13 = intersect(terms1, rownames(a12));  	a13[1:15];	length(a13)
    a14a = match(a13, terms1); 		# positions of matching terms in mat1 matrix
    a14b = match(a13, rownames(a12))		
    a15 = mat1[a14a,]*matrix(rep(a12[a14b,], ncol(mat1)), ncol = ncol(mat1))
    eta.mat = rbind(eta.mat, apply(a15, 2, mean))	
    rm(a11, a12, a13, a14a, a14b, a15)
  }
  eta.mat = eta.mat[2:nrow(eta.mat), ] 	# remove top zeroes row
  row.names(eta.mat)=row.names(dtm)
  return(eta.mat)
}

twc = eta(lift,dtm1)

##############################################
# Find Document by each topic

eta.file = function(mat,calib,n) {
  s = list()
  
  for (i in  1: ncol(mat))
  {read_doc = mat[order(mat[,i], decreasing= T),]
  read_names = row.names(read_doc[1:n,])  
  s[[i]] = calib[(match(read_names, calib$Doc.id)),2]
  }
  return(s)
}

temp=eta.file(twc,calib,5)

for (j in 1:length(temp)){
  cat("\n")
  cat("################################# \n")
  cat("Top ", 5, "documents for topic ",j,"\n")
  cat("################################# \n")
  cat("\n")
  #print(paste("Top 10 documents heavily loading on topic",j) )
  print(temp[[j]])
}




